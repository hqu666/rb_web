<?php
//echo nl2br(print_r($_SERVER,true));
print json_encode($_SERVER);
?>